/**
 * Created by Boubou on 28/06/2016.
 * Updated By Guillaume on 26/10/2016.
 */
(function ($) {
  var $newsletterBtn = $('<a class="block block-small global-newsletter-form" href="#newsletter">' +
    ' <span class="icon icon-newsletter"></span>' +
    ' <span class="txt-btn">Newsletter</span>' +
    '</a>');
  var $newsletterClose = $('<a />').attr('href', '#close').addClass('icon-close-newsletter');
  var $newsletterBlock = $('.block-page.newsletter-form');


  $(document).ready(function () {
    $newsletterBtn.insertAfter(".site-banner .quicklinks.links");
    resizeNLBlock();
    $newsletterClose.insertBefore("div.newsletter-form .nf-main-content.cxp-newsletter .box-dark");
  });

  function resizeNLBlock() {
    var logo_space = ($(".site-banner-event").width() > 0) ? $('.site-banner-event').outerWidth(true) : $('.site-banner-site-banner-title').outerWidth(true);
    var button_space = $('#icon-newsletter-block').outerWidth(true) + $('.site-banner .gsf-trigger').outerWidth(true) + $('.site-banner .ls-trigger').outerWidth(true);
    var empty_space = $(window).width() - (logo_space + button_space + 2);

    $('.site-banner .main-navigation').width(empty_space);
  }

  $(window).resize(function () {
    resizeNLBlock();
  });

  $newsletterBtn.click(function (e) {
    e.preventDefault();
    $newsletterBlock.show();
  });

  $(document).on('click', '.block-page.newsletter-form', function (e) {
    if (e.target != this) return;
    $newsletterBlock.hide();
  });

  $(document).on('click', '.newsletter-form .icon-close-newsletter', function (e) {
    if (e.target != this) return;
    $newsletterBlock.hide();
  });

})(jQuery);
